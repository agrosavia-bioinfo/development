The following files are included with this distribution.

For Windows:   		GWASpoly_1.3.zip
For MacOS and Linux:	GWASpoly_1.3.tar.gz
Reference manual:	GWASpoly_manual.pdf
Vignette:		GWASpoly_vignette.pdf
Tutorial Dataset:	TableS1.csv, TableS2.csv