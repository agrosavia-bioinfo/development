#!/usr/bin/Rscript

# Process Berdugo's genotype:
# Get from dossage AABB alleles, and convert to:
# AABB, numeric (0,1,2,3,4), and ACGT
# 

source ("lglib01.R")

#----------------------------------------------------------
# Convert numeric (gwaspoly) genotype to ACGT using solcap ref/alt alleles
# Basic genotype: [Markers+Alleles]
#----------------------------------------------------------
numericToACGTFormatGenotype <- function (genotypeFile, SNPsFile) 
{
	genotype     <- read.csv (genotypeFile, header=T, check.names=F)
	SNPs         <- read.csv (SNPsFile, header=T, check.names=F)
	rownames (SNPs) <- SNPs [,1]
	alleles      <- genotype [,-c(2,3)]; hd (alleles)
	allelesACGT  <- numericToACGTFormatAlleles (alleles, SNPs); hd (allelesACGT)
	genoACGT     = data.frame (genotype [,1:3], allelesACGT [,-1])

	outFile = paste0 (strsplit (genotypeFile, split="[.]")[[1]][1],"-ACGT.csv")
	#msgmsg ("Writing ACGT genotype to ", outFile, "...")
	write.csv (genoACGT, outFile, row.names=F)
}

numericToACGTFormatAlleles <- function (alleles, SNPs) 
{
	setA <- function (allelesVec, refs, alts) {
		id  = allelesVec [1]
		gnt <- as.numeric (allelesVec [-1])
		ref = alts [id,2]
		alt = refs [id,2]
		gnt [gnt==4] = strrep(ref,4)
		gnt [gnt==3] = paste0 (strrep(alt,1),strrep(ref,3))
		gnt [gnt==2] = paste0 (strrep(alt,2),strrep(ref,2))
		gnt [gnt==1] = paste0 (strrep(alt,3),strrep(ref,1))
		gnt [gnt==0] = strrep(alt,4)
		return (gnt)
	}
	refs <- data.frame (SNPs [,c(1,4)])
	rownames (refs) <- SNPs [,1]
	alts <- data.frame (SNPs [,c(1,5)])
	rownames (alts) <- SNPs [,1]
	alls <- alleles

	allelesNUM <- t(apply (alleles,  1, setA, refs, alts ))
	colnames (allelesNUM) = colnames (alleles [-1])
	rownames (allelesNUM) = rownames (alleles)

	newAlleles <- data.frame (Markers=alleles [,1], allelesNUM)
	return (newAlleles)
}

#----------------------------------------------------------
# Add tabs to alleels changign AG --> A	G
#----------------------------------------------------------
convertAllelesAABBToNumeric <- function (allelesAB) {
	# >>>>>> Function
	setNum <- function (alleles) {
		alleles [alleles=="AAAA"] = 0
		alleles [alleles=="AAAB"] = 1
		alleles [alleles=="AABB"] = 2
		alleles [alleles=="ABBB"] = 3
		alleles [alleles=="BBBB"] = 4
		return (alleles)
	}
	# >>>>>> 

	allelesNum  <- t(apply (allelesAB, 1, setNum))
	#rownames (numMat) = allelesMat [,1]

	return (allelesNum)
}
#----------------------------------------------------------
# Main
#----------------------------------------------------------

#filenameGeno = "
#args = c ("berdugo-genotype-s003-sample100-CLEAN.csv", "potato-infinium-8303-alt-ref.csv"
filenameGeno    = args [1]
refAltFilename  = args [2]

geno = read.csv (filenameGeno); hd (geno)

# Select "And_XX" and "AABB" alleles
message (">>> Filtering And_XX and selecting AABB from dosages...")
alleles    = geno [,-1:-3]; hd (alleles)
andNames   = grepl ("And", colnames (alleles))
allelesAnd = alleles [,andNames]; hd (allelesAnd)
nr = nrow (allelesAnd)
nc = ncol (allelesAnd)

# Get AABB alleles
message (">> Wrrintin AABB geno...")
seqAlleles = seq (1, nc, 2)
allelesAB  = allelesAnd [,seqAlleles]; hd (allelesAB)
genoAB          = cbind (geno[,1:3], allelesAB); hd (genoAB)
genoABFilename  = addLabel (filenameGeno, "AABB")
write.csv (genoAB, genoABFilename, quote=F, row.names=F)

message (">>> Converting from AABB to numeric...")
# Convert alleles AB to Num
allelesNum = convertAllelesAABBToNumeric (allelesAB);hd (allelesNum)

message (">>> Converting from numeric to ACGT...")
genoNum          = cbind (geno[,1:3], allelesNum); hd (genoNum)
genoNumFilename      = addLabel (filenameGeno, "NUM")
write.csv (genoNum, genoNumFilename, quote=F, row.names=F)

numericToACGTFormatGenotype (genoNumFilename, refAltFilename)

#----------------------------------------------------------


