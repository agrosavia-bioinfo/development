cmm="formatNumToACGT.R agrosavia-genotype-NUM-CLEANED-MAP.csv agrosavia-genotype-MAP-altref.csv"
echo $cmm;eval $cmm
cmm="mv agrosavia-genotype-NUM-CLEANED-MAP-ACGT.csv agrosavia-genotype-ACGT-CLEANED-MAP.csv"
echo $cmm;eval $cmm
cmm="filter-common-samples.R agrosavia-genotype-ACGT-CLEANED-MAP.csv agrosavia-phenotype-GOTA-CLEANED.csv"
echo $cmm;eval $cmm
cmm="gwaspoly-example.R agrosavia-genotype-ACGT-CLEANED-MAP-COMMON.csv agrosavia-phenotype-GOTA-CLEANED-COMMON.csv"
echo $cmm;eval $cmm


