Markers in ClusterCall Genotype   : 3280
Markers in Berdugo Paper Genotype : 4435

Difference: 1255 Markers
