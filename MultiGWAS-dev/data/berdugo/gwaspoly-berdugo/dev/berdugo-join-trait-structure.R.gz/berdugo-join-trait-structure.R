#!/usr/bin/Rscript
source ("lglib01.R")

# Join trait with structure in one table
# trait is standardized as strusture was done

traitFile  = "agrosavia-phenotype-GOTA-CLEANED.csv"
structFile = "K5_estructura_tetraploides_2017.csv"

normalize <- function(x){(x-min(x))/(max(x)-min(x))}

# Read and normalize trait
trait    = read.csv (traitFile)
rownames (trait) = trait [,1]
trait[,2] = normalize (trait[,2])
hd (trait)
struct = read.csv (structFile)
rownames (struct) = struct [,1]
hd (struct)


# Get common names
commonNames = intersect (trait [,1], struct [,1])

commonTraits  =  trait  [commonNames,]
hd (commonTraits)
commonStruct  =  struct [commonNames,]
hd (commonStruct)

# Join and write results
traitStruct = cbind (commonTraits, commonStruct[,-1])

outFile = paste0 (strsplit (traitFile, "\\.")[[1]][1], "-STRUCT.csv")
write.csv (traitStruct, outFile, quote=F, row.names=F)


	
