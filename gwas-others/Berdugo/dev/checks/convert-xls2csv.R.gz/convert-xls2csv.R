#!/usr/bin/Rscript

# Convert a xlsx file to csv file

library (rio)

args = commandArgs()
#args = "berdugo-genotype-s003.xlsx"
filename = args [1]
name = unlist (strsplit(filename, ".", fixed=T))[[1]]
newname = sprintf ("%s.csv", name)
write (sprintf ("\nConverting %s to %s ...\n", filename, newname))
convert (filename, newname)
