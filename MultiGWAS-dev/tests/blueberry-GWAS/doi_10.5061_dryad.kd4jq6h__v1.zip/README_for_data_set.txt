Tetraploid_SNPdata.csv = pre-filtered SNP data set identified in the blueberry population, with dimensions of 80591 x 1562 (marker x individual). Three first columns represent the SNP name, scaffold, and position within the scaffold, respectively. The remaining column names refer to the genotype identification.  

Tetraploid_phenotypic_data = phenotypic data set. First column represents the genotype identification. Other columns are the phenotypic values for eight blueberry traits: weight, size, firmness, stem scar diameter, pH, soluble solids content, flower bud density, and yield. 

Diploid_SNPdata.csv = pre-filtered SNP data set identified in the blueberry population, with dimensions of 77496 x 1560 (marker x individual). Three first columns represent the SNP name, scaffold, and position within the scaffold, respectively. The remaining column names refer to the genotype identification.  

Diploid_phenotypic_data = phenotypic data set. First column represents the genotypes identification. Other columns are the phenotypic values for eight blueberry traits: weight, size, firmness, stem scar diameter, pH, soluble solids content, flower bud density, and yield. 
