#!/usr/bin/Rscript

source ("lglib01.R")

# Add map information (chr, pos) to k-matrix genotype
# INPUTS: a k-matrix genotype, and, map file

#args = c ("agrosavia-genotype-ACGT-CLEANED.tbl",
#		  "agrosavia-genotype-MAP-altref.tbl")

genoFile = args [1]
mapFile  = args [2]

# Read data
geno = read.csv (genoFile, check.names=F)
hd (geno)
map  = read.csv (mapFile)
hd (map)

# Merge
sel = merge (map [,1:3], geno, by.x=1, by.y=1)
hd (sel)

outFile = addLabel (genoFile, "MAP")
write.csv (file=outFile, sel, quote=F, row.names=F)
		
